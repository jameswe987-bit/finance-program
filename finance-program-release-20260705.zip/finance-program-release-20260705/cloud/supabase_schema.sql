-- 建议在 Supabase SQL Editor 中运行
-- 第一阶段：低风险云端同步结构

create extension if not exists pgcrypto;

create table if not exists public.finance_organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null default '项目财务系统',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.finance_profiles (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.finance_organizations(id) on delete cascade,
  auth_user_id uuid,
  username text not null,
  display_name text not null,
  role text not null default '查看员',
  status text not null default '启用',
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, username)
);

create table if not exists public.finance_state_documents (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.finance_organizations(id) on delete cascade,
  document_key text not null default 'main',
  payload jsonb not null default '{}'::jsonb,
  version bigint not null default 1,
  updated_by uuid references public.finance_profiles(id) on delete set null,
  updated_at timestamptz not null default now(),
  unique (organization_id, document_key)
);

create table if not exists public.finance_state_backups (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.finance_organizations(id) on delete cascade,
  document_key text not null default 'main',
  payload jsonb not null default '{}'::jsonb,
  version bigint not null,
  backup_reason text not null default 'manual',
  created_by uuid references public.finance_profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.finance_files (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.finance_organizations(id) on delete cascade,
  owner_module text not null,
  owner_id text,
  file_name text not null,
  file_path text not null,
  mime_type text,
  size_bytes bigint default 0,
  public_url text,
  uploaded_by uuid references public.finance_profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.finance_audit_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.finance_organizations(id) on delete cascade,
  profile_id uuid references public.finance_profiles(id) on delete set null,
  action text not null,
  module_name text,
  record_id text,
  before_payload jsonb,
  after_payload jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_finance_profiles_org on public.finance_profiles(organization_id);
create index if not exists idx_finance_state_documents_org on public.finance_state_documents(organization_id);
create index if not exists idx_finance_files_org_module on public.finance_files(organization_id, owner_module);
create index if not exists idx_finance_audit_logs_org_time on public.finance_audit_logs(organization_id, created_at desc);

alter table public.finance_organizations enable row level security;
alter table public.finance_profiles enable row level security;
alter table public.finance_state_documents enable row level security;
alter table public.finance_state_backups enable row level security;
alter table public.finance_files enable row level security;
alter table public.finance_audit_logs enable row level security;

-- 第一阶段测试期策略：登录用户可以读写。
-- 正式多人使用时，建议再按 organization_id 和 role 细分权限。

create policy "authenticated read organizations"
on public.finance_organizations for select
to authenticated
using (true);

create policy "authenticated write organizations"
on public.finance_organizations for all
to authenticated
using (true)
with check (true);

create policy "authenticated read profiles"
on public.finance_profiles for select
to authenticated
using (true);

create policy "authenticated write profiles"
on public.finance_profiles for all
to authenticated
using (true)
with check (true);

create policy "authenticated read state"
on public.finance_state_documents for select
to authenticated
using (true);

create policy "authenticated write state"
on public.finance_state_documents for all
to authenticated
using (true)
with check (true);

create policy "authenticated read backups"
on public.finance_state_backups for select
to authenticated
using (true);

create policy "authenticated write backups"
on public.finance_state_backups for all
to authenticated
using (true)
with check (true);

create policy "authenticated read files"
on public.finance_files for select
to authenticated
using (true);

create policy "authenticated write files"
on public.finance_files for all
to authenticated
using (true)
with check (true);

create policy "authenticated read audit logs"
on public.finance_audit_logs for select
to authenticated
using (true);

create policy "authenticated write audit logs"
on public.finance_audit_logs for all
to authenticated
using (true)
with check (true);

insert into public.finance_organizations (name)
values ('项目财务系统')
on conflict do nothing;
