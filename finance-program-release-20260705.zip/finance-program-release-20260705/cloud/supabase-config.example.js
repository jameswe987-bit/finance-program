// 复制这个文件为 supabase-config.js
// 然后填入 Supabase 项目的 URL 和 anon key

window.FINANCE_CLOUD_CONFIG = {
  enabled: false,
  provider: "supabase",
  supabaseUrl: "https://你的项目.supabase.co",
  supabaseAnonKey: "你的 anon public key",
  organizationName: "项目财务系统",
  documentKey: "main",
  storageBucket: "finance-files",
};
